<?php
$categories = getCategories();
$username = $user['username'] ?? 'Player';
$isGuest = $user['isGuest'] ?? true;
$initial = strtoupper($username[0]);
?>
<div class="min-h-screen bg-gradient-to-br from-purple-500 via-pink-500 to-orange-500">
  <div class="p-4 flex justify-between items-center">
    <a href="index.php?page=profile" class="flex items-center gap-2 bg-white/20 backdrop-blur-sm rounded-full px-4 py-2 text-white hover:bg-white/30 transition-colors">
      <div class="w-8 h-8 bg-white rounded-full flex items-center justify-center text-purple-600 font-bold">
        <?= htmlspecialchars($initial) ?>
      </div>
      <span class="font-semibold"><?= htmlspecialchars($username) ?></span>
    </a>
    <?php if (!$isGuest): ?>
      <a href="index.php?page=leaderboard" class="bg-white/20 backdrop-blur-sm rounded-full px-4 py-2 text-white hover:bg-white/30 transition-colors font-semibold">
        🏆 Leaderboard
      </a>
    <?php endif; ?>
  </div>

  <div class="flex items-center justify-center p-4 min-h-[calc(100vh-80px)]">
    <div class="w-full max-w-md">
      <div class="text-center mb-8">
        <h1 class="text-5xl font-bold text-white mb-2">QuizMaster</h1>
        <p class="text-white/90 text-lg">Select your categories and start playing!</p>
      </div>

      <form method="POST" action="index.php" id="quizForm">
        <input type="hidden" name="action" value="start_quiz">
        <div class="space-y-3 mb-6" id="categoryList">
          <?php foreach ($categories as $cat): ?>
            <label class="block cursor-pointer">
              <input type="checkbox" name="categories[]" value="<?= htmlspecialchars($cat['id']) ?>" class="hidden category-checkbox" onchange="updateUI()">
              <div class="category-btn w-full p-5 rounded-2xl transition-all duration-200 bg-white/20 backdrop-blur-sm hover:bg-white/30 border-2 border-transparent">
                <div class="flex items-center justify-between">
                  <div class="flex items-center gap-3">
                    <span class="text-3xl"><?= $cat['emoji'] ?></span>
                    <div class="text-left">
                      <h3 class="font-bold text-lg text-white category-name"><?= htmlspecialchars($cat['name']) ?></h3>
                      <p class="text-sm text-white/80"><?= count($cat['questions']) ?> questions</p>
                    </div>
                  </div>
                  <div class="check-circle w-6 h-6 rounded-full border-2 border-white bg-transparent flex items-center justify-center">
                    <svg class="check-icon w-4 h-4 text-white hidden" fill="currentColor" viewBox="0 0 20 20">
                      <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
                    </svg>
                  </div>
                </div>
              </div>
            </label>
          <?php endforeach; ?>
        </div>

        <button type="submit" id="startBtn" disabled
          class="w-full py-4 rounded-2xl font-bold text-xl transition-all duration-200 bg-white/20 text-white/50 cursor-not-allowed">
          Select at least one category
        </button>
      </form>
    </div>
  </div>
</div>

<script>
function updateUI() {
  const checkboxes = document.querySelectorAll('.category-checkbox');
  const startBtn = document.getElementById('startBtn');
  let count = 0;

  checkboxes.forEach((cb, i) => {
    const label = cb.closest('label');
    const btn = label.querySelector('.category-btn');
    const circle = label.querySelector('.check-circle');
    const icon = label.querySelector('.check-icon');
    const name = label.querySelector('.category-name');

    if (cb.checked) {
      count++;
      btn.classList.remove('bg-white/20', 'hover:bg-white/30');
      btn.classList.add('bg-white', 'shadow-lg', 'scale-105');
      name.classList.remove('text-white');
      name.classList.add('text-gray-800');
      circle.classList.remove('border-white', 'bg-transparent');
      circle.classList.add('bg-purple-500', 'border-purple-500');
      icon.classList.remove('hidden');
    } else {
      btn.classList.add('bg-white/20', 'hover:bg-white/30');
      btn.classList.remove('bg-white', 'shadow-lg', 'scale-105');
      name.classList.add('text-white');
      name.classList.remove('text-gray-800');
      circle.classList.add('border-white', 'bg-transparent');
      circle.classList.remove('bg-purple-500', 'border-purple-500');
      icon.classList.add('hidden');
    }
  });

  if (count > 0) {
    startBtn.disabled = false;
    startBtn.className = 'w-full py-4 rounded-2xl font-bold text-xl transition-all duration-200 bg-white text-purple-600 shadow-lg hover:shadow-xl hover:scale-105 cursor-pointer';
    startBtn.textContent = 'Start Quiz';
  } else {
    startBtn.disabled = true;
    startBtn.className = 'w-full py-4 rounded-2xl font-bold text-xl transition-all duration-200 bg-white/20 text-white/50 cursor-not-allowed';
    startBtn.textContent = 'Select at least one category';
  }
}
</script>
