<?php
$quiz = $_SESSION['last_quiz'];
$score = $quiz['score'];
$total = count($quiz['questions']);
$selected = $quiz['selectedCategories'];
$percentage = $total > 0 ? (int)round(($score / $total) * 100) : 0;

$isSingle = count($selected) === 1;
$categoryId = $isSingle ? $selected[0] : '';
$category = $isSingle ? getCategoryById($categoryId) : null;
$categoryName = $category ? $category['name'] : 'Mixed';
$categoryEmoji = $category ? $category['emoji'] : '🎯';

$isGuest = $user['isGuest'] ?? true;
$userRank = null;
if (!$isGuest && $isSingle) {
    $userRank = getUserRankInCategory($user['id'], $categoryId);
}

if ($percentage === 100) { $message = 'Perfect Score!'; $emoji = '🏆'; }
elseif ($percentage >= 80) { $message = 'Excellent!'; $emoji = '🎉'; }
elseif ($percentage >= 60) { $message = 'Good Job!'; $emoji = '👍'; }
elseif ($percentage >= 40) { $message = 'Not Bad!'; $emoji = '😊'; }
else { $message = 'Keep Practicing!'; $emoji = '💪'; }
?>
<div class="min-h-screen bg-gradient-to-br from-green-500 via-teal-500 to-blue-500 flex items-center justify-center p-4">
  <div class="w-full max-w-md">
    <div class="bg-white rounded-3xl p-8 shadow-2xl text-center">
      <div class="text-8xl mb-6"><?= $emoji ?></div>
      <h1 class="text-4xl font-bold text-gray-800 mb-2"><?= htmlspecialchars($message) ?></h1>
      <p class="text-gray-600 text-lg mb-8">Quiz Complete!</p>

      <div class="bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl p-8 mb-8">
        <div class="text-white mb-4">
          <div class="text-6xl font-bold mb-2"><?= $score ?></div>
          <div class="text-2xl">out of <?= $total ?></div>
        </div>
        <div class="h-3 bg-white/30 rounded-full overflow-hidden">
          <div class="h-full bg-white transition-all duration-500" style="width: <?= $percentage ?>%"></div>
        </div>
        <div class="text-white/90 mt-2 text-xl font-semibold"><?= $percentage ?>% Correct</div>
      </div>

      <div class="grid grid-cols-2 gap-3 mb-6">
        <div class="bg-green-50 rounded-xl p-4">
          <div class="text-3xl font-bold text-green-600"><?= $score ?></div>
          <div class="text-green-700 text-sm">Correct</div>
        </div>
        <div class="bg-red-50 rounded-xl p-4">
          <div class="text-3xl font-bold text-red-600"><?= $total - $score ?></div>
          <div class="text-red-700 text-sm">Wrong</div>
        </div>
      </div>

      <?php if (!$isGuest && $userRank): ?>
        <div class="mb-6 bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-4 border-2 border-purple-200">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-3">
              <div class="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-white font-bold text-lg">
                #<?= $userRank ?>
              </div>
              <div>
                <p class="text-sm text-gray-600">Your Rank in</p>
                <p class="font-bold text-gray-800"><?= $categoryEmoji ?> <?= htmlspecialchars($categoryName) ?></p>
              </div>
            </div>
            <svg class="w-8 h-8 text-purple-500" fill="currentColor" viewBox="0 0 20 20">
              <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
            </svg>
          </div>
        </div>
      <?php endif; ?>

      <div class="space-y-3">
        <form method="POST" action="index.php">
          <input type="hidden" name="action" value="play_again">
          <button type="submit" class="w-full py-4 rounded-2xl font-bold text-xl bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-200">
            Play Again
          </button>
        </form>
        <?php if (!$isGuest && $isSingle): ?>
          <a href="index.php?page=leaderboard&category=<?= urlencode($categoryId) ?>" class="block w-full py-4 rounded-2xl font-bold text-xl bg-gradient-to-r from-blue-500 to-indigo-500 text-white shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-200 text-center">
            View Leaderboard
          </a>
        <?php endif; ?>
        <a href="index.php?page=category-select" class="block w-full py-4 rounded-2xl font-bold text-xl bg-gray-100 text-gray-700 hover:bg-gray-200 transition-all duration-200 text-center">
          Back to Menu
        </a>
      </div>
    </div>
  </div>
</div>
