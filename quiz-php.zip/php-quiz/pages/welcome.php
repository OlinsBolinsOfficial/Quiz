<div class="min-h-screen bg-gradient-to-br from-purple-600 via-pink-600 to-orange-500 flex items-center justify-center p-4">
  <div class="w-full max-w-md">
    <div class="text-center mb-12">
      <div class="text-7xl mb-4">🎯</div>
      <h1 class="text-6xl font-bold text-white mb-3">QuizMaster</h1>
      <p class="text-white/90 text-xl">Test your knowledge across 5 categories!</p>
    </div>

    <div class="space-y-4">
      <a href="index.php?page=login" class="block w-full py-5 rounded-2xl font-bold text-xl bg-white text-purple-600 shadow-lg hover:shadow-xl text-center transition-all hover:scale-105">
        Log In
      </a>
      <a href="index.php?page=signup" class="block w-full py-5 rounded-2xl font-bold text-xl bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg hover:shadow-xl text-center transition-all hover:scale-105">
        Create Account
      </a>
      <form method="POST" action="index.php">
        <input type="hidden" name="action" value="guest">
        <button type="submit" class="w-full py-5 rounded-2xl font-bold text-xl bg-white/20 backdrop-blur-sm text-white hover:bg-white/30 transition-all duration-200">
          Continue as Guest
        </button>
      </form>
    </div>

    <p class="text-white/70 text-sm text-center mt-6">
      Create an account to save your progress and compete on the leaderboard!
    </p>
  </div>
</div>
