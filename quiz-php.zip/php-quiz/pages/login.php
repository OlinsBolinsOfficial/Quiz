<?php $error = $_SESSION['error'] ?? ''; $_SESSION['error'] = ''; ?>
<div class="min-h-screen bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 flex items-center justify-center p-4">
  <div class="w-full max-w-md">
    <a href="index.php?page=welcome" class="mb-6 text-white/90 hover:text-white flex items-center gap-2 transition-colors inline-flex">
      <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      Back
    </a>

    <div class="bg-white rounded-3xl p-8 shadow-2xl mt-6">
      <h1 class="text-4xl font-bold text-gray-800 mb-2 text-center">Welcome Back!</h1>
      <p class="text-gray-600 text-center mb-8">Log in to continue your quiz journey</p>

      <form method="POST" action="index.php" class="space-y-4">
        <input type="hidden" name="action" value="login">
        <div>
          <label class="block text-gray-700 font-semibold mb-2">Username</label>
          <input type="text" name="username" class="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-purple-500 focus:outline-none transition-colors" placeholder="Enter your username" required>
        </div>
        <div>
          <label class="block text-gray-700 font-semibold mb-2">Password</label>
          <input type="password" name="password" class="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-purple-500 focus:outline-none transition-colors" placeholder="Enter your password" required>
        </div>
        <?php if ($error): ?>
          <div class="bg-red-50 text-red-600 px-4 py-3 rounded-xl text-sm"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <button type="submit" class="w-full py-4 rounded-2xl font-bold text-xl bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg hover:shadow-xl transition-all hover:scale-105">
          Log In
        </button>
      </form>

      <div class="mt-6 text-center">
        <span class="text-gray-600">Don't have an account? </span>
        <a href="index.php?page=signup" class="text-purple-600 font-semibold hover:text-purple-700 transition-colors">Sign up</a>
      </div>
    </div>
  </div>
</div>
