<?php
$stats = getUserStats($user['id']);
$categories = getCategories();
$totalCorrect = array_sum(array_column($stats['categoryScores'], 'bestScore'));
$totalQuestions = array_sum(array_column($stats['categoryScores'], 'totalQuestions'));
$overallPct = $totalQuestions > 0 ? (int)round(($totalCorrect / $totalQuestions) * 100) : 0;
$initial = strtoupper($user['username'][0]);
$isGuest = $user['isGuest'] ?? true;
?>
<div class="min-h-screen bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 p-4">
  <div class="max-w-2xl mx-auto py-6">
    <div class="flex items-center justify-between mb-6">
      <a href="index.php?page=category-select" class="text-white/90 hover:text-white flex items-center gap-2 transition-colors">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
        </svg>
        Back
      </a>
      <form method="POST" action="index.php">
        <input type="hidden" name="action" value="logout">
        <button type="submit" class="text-white/90 hover:text-white transition-colors font-semibold">Log Out</button>
      </form>
    </div>

    <div class="bg-white rounded-3xl p-8 shadow-2xl mb-6">
      <div class="text-center mb-6">
        <div class="w-24 h-24 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full mx-auto mb-4 flex items-center justify-center text-4xl text-white font-bold">
          <?= htmlspecialchars($initial) ?>
        </div>
        <h1 class="text-3xl font-bold text-gray-800 mb-1"><?= htmlspecialchars($user['username']) ?></h1>
        <?php if ($isGuest): ?><p class="text-gray-500 text-sm">Guest Account</p><?php endif; ?>
      </div>

      <div class="grid grid-cols-3 gap-4 mb-6">
        <div class="bg-purple-50 rounded-xl p-4 text-center">
          <div class="text-3xl font-bold text-purple-600"><?= $stats['totalGamesPlayed'] ?></div>
          <div class="text-purple-700 text-sm mt-1">Games Played</div>
        </div>
        <div class="bg-pink-50 rounded-xl p-4 text-center">
          <div class="text-3xl font-bold text-pink-600"><?= $overallPct ?>%</div>
          <div class="text-pink-700 text-sm mt-1">Average Score</div>
        </div>
        <div class="bg-orange-50 rounded-xl p-4 text-center">
          <div class="text-3xl font-bold text-orange-600"><?= count($stats['categoryScores']) ?></div>
          <div class="text-orange-700 text-sm mt-1">Categories</div>
        </div>
      </div>

      <div class="border-t-2 border-gray-100 pt-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Best Scores by Category</h2>
        <?php if (empty($stats['categoryScores'])): ?>
          <p class="text-gray-500 text-center py-8">No games played yet. Start a quiz to see your stats!</p>
        <?php else: ?>
          <div class="space-y-3">
            <?php foreach ($categories as $cat):
              $cs = null;
              foreach ($stats['categoryScores'] as $s) { if ($s['categoryId'] === $cat['id']) { $cs = $s; break; } }
              if (!$cs) continue;
              $pct = (int)round(($cs['bestScore'] / $cs['totalQuestions']) * 100);
            ?>
              <div class="bg-gray-50 rounded-xl p-4 hover:bg-gray-100 transition-colors">
                <div class="flex items-center justify-between mb-2">
                  <div class="flex items-center gap-3">
                    <span class="text-2xl"><?= $cat['emoji'] ?></span>
                    <div>
                      <h3 class="font-bold text-gray-800"><?= htmlspecialchars($cat['name']) ?></h3>
                      <p class="text-sm text-gray-600"><?= $cs['attempts'] ?> attempt<?= $cs['attempts'] !== 1 ? 's' : '' ?></p>
                    </div>
                  </div>
                  <div class="text-right">
                    <div class="text-2xl font-bold text-purple-600"><?= $cs['bestScore'] ?>/<?= $cs['totalQuestions'] ?></div>
                    <div class="text-sm text-gray-600"><?= $pct ?>%</div>
                  </div>
                </div>
                <?php if (!$isGuest): ?>
                  <a href="index.php?page=leaderboard&category=<?= urlencode($cat['id']) ?>" class="block w-full mt-2 py-2 px-4 bg-white rounded-lg text-sm font-semibold text-purple-600 hover:bg-purple-50 transition-colors text-center">
                    View Leaderboard
                  </a>
                <?php endif; ?>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>

    <?php if ($isGuest): ?>
      <div class="bg-yellow-50 border-2 border-yellow-200 rounded-2xl p-4 text-center">
        <p class="text-yellow-800 font-semibold mb-2">Guest accounts cannot access leaderboards</p>
        <p class="text-yellow-700 text-sm">Create an account to compete with other players!</p>
      </div>
    <?php endif; ?>
  </div>
</div>
