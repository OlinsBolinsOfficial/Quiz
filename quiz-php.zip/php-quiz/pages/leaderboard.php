<?php
$categories = getCategories();
$selectedCategory = $_GET['category'] ?? $categories[0]['id'];
// Validate
$validIds = array_column($categories, 'id');
if (!in_array($selectedCategory, $validIds)) $selectedCategory = $categories[0]['id'];

$currentUserId = $user['id'] ?? '';
$leaderboardData = getLeaderboard($selectedCategory, $currentUserId);
$catData = getCategoryById($selectedCategory);

function getMedal(int $rank): string {
    return match($rank) { 1 => '🥇', 2 => '🥈', 3 => '🥉', default => '' };
}
?>
<div class="min-h-screen bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-600 p-4">
  <div class="max-w-3xl mx-auto py-6">
    <a href="index.php?page=category-select" class="mb-6 text-white/90 hover:text-white flex items-center gap-2 transition-colors inline-flex">
      <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      Back
    </a>

    <div class="text-center mb-8 mt-6">
      <h1 class="text-5xl font-bold text-white mb-2">Leaderboard</h1>
      <p class="text-white/90 text-lg">Compete with the best!</p>
    </div>

    <!-- Category tabs -->
    <div class="mb-6 overflow-x-auto">
      <div class="flex gap-2 pb-2">
        <?php foreach ($categories as $cat):
          $isSelected = $cat['id'] === $selectedCategory;
        ?>
          <a href="index.php?page=leaderboard&category=<?= urlencode($cat['id']) ?>"
            class="flex-shrink-0 px-4 py-3 rounded-xl font-semibold transition-all duration-200 <?= $isSelected ? 'bg-white text-purple-600 shadow-lg' : 'bg-white/20 backdrop-blur-sm text-white hover:bg-white/30' ?>">
            <span class="mr-2"><?= $cat['emoji'] ?></span><?= htmlspecialchars($cat['name']) ?>
          </a>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Leaderboard table -->
    <div class="bg-white rounded-3xl p-6 shadow-2xl">
      <div class="flex items-center gap-3 mb-6 pb-4 border-b-2 border-gray-100">
        <span class="text-4xl"><?= $catData['emoji'] ?></span>
        <div>
          <h2 class="text-2xl font-bold text-gray-800"><?= htmlspecialchars($catData['name']) ?></h2>
          <p class="text-gray-600"><?= count($leaderboardData) ?> player<?= count($leaderboardData) !== 1 ? 's' : '' ?></p>
        </div>
      </div>

      <?php if (empty($leaderboardData)): ?>
        <div class="text-center py-12">
          <div class="text-6xl mb-4">🏆</div>
          <p class="text-gray-500 text-lg">No scores yet in this category.</p>
          <p class="text-gray-400 text-sm mt-2">Be the first to play!</p>
        </div>
      <?php else: ?>
        <div class="space-y-2">
          <?php foreach ($leaderboardData as $entry):
            $medal = getMedal($entry['rank']);
            $isTop3 = $entry['rank'] <= 3;
            $isMe = $entry['isCurrentUser'];
            if ($isMe) $rowClass = 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg scale-105';
            elseif ($isTop3) $rowClass = 'bg-gradient-to-r from-yellow-50 to-orange-50';
            else $rowClass = 'bg-gray-50 hover:bg-gray-100';
          ?>
            <div class="p-4 rounded-xl transition-all duration-200 <?= $rowClass ?>">
              <div class="flex items-center justify-between">
                <div class="flex items-center gap-4 flex-1">
                  <div class="flex items-center justify-center w-10 h-10 rounded-full font-bold
                    <?= $isMe ? 'bg-white/20 text-white' : ($isTop3 ? 'bg-white text-orange-600' : 'bg-gray-200 text-gray-600') ?>">
                    <?= $medal ?: $entry['rank'] ?>
                  </div>
                  <div class="flex-1">
                    <div class="flex items-center gap-2">
                      <h3 class="font-bold text-lg <?= $isMe ? 'text-white' : 'text-gray-800' ?>">
                        <?= htmlspecialchars($entry['username']) ?>
                      </h3>
                      <?php if ($isMe): ?>
                        <span class="bg-white/20 px-2 py-0.5 rounded-full text-xs font-semibold">You</span>
                      <?php endif; ?>
                    </div>
                    <p class="text-sm <?= $isMe ? 'text-white/80' : 'text-gray-600' ?>">
                      <?= $entry['score'] ?> / <?= $entry['totalQuestions'] ?> correct
                    </p>
                  </div>
                </div>
                <div class="text-right">
                  <div class="text-3xl font-bold <?= $isMe ? 'text-white' : ($isTop3 ? 'text-orange-600' : 'text-purple-600') ?>">
                    <?= $entry['percentage'] ?>%
                  </div>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>

    <div class="mt-6 bg-white/10 backdrop-blur-sm rounded-2xl p-4 text-white">
      <h3 class="font-bold mb-2">Leaderboard Rules:</h3>
      <ul class="text-sm space-y-1 text-white/90">
        <li>• Only registered users appear on leaderboards</li>
        <li>• Your best score per category is shown</li>
        <li>• Rankings are based on percentage correct</li>
        <li>• Play more to improve your ranking!</li>
      </ul>
    </div>
  </div>
</div>
