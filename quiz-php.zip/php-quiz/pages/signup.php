<?php $error = $_SESSION['error'] ?? ''; $_SESSION['error'] = ''; ?>
<div class="min-h-screen bg-gradient-to-br from-green-600 via-teal-600 to-blue-600 flex items-center justify-center p-4">
  <div class="w-full max-w-md">
    <a href="index.php?page=welcome" class="mb-6 text-white/90 hover:text-white flex items-center gap-2 transition-colors inline-flex">
      <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      Back
    </a>

    <div class="bg-white rounded-3xl p-8 shadow-2xl mt-6">
      <h1 class="text-4xl font-bold text-gray-800 mb-2 text-center">Create Account</h1>
      <p class="text-gray-600 text-center mb-8">Join the quiz community!</p>

      <form method="POST" action="index.php" class="space-y-4">
        <input type="hidden" name="action" value="signup">
        <div>
          <label class="block text-gray-700 font-semibold mb-2">Username</label>
          <input type="text" name="username" class="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-teal-500 focus:outline-none transition-colors" placeholder="Choose a username" required>
        </div>
        <div>
          <label class="block text-gray-700 font-semibold mb-2">Password</label>
          <input type="password" name="password" class="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-teal-500 focus:outline-none transition-colors" placeholder="Choose a password" required>
        </div>
        <div>
          <label class="block text-gray-700 font-semibold mb-2">Confirm Password</label>
          <input type="password" name="confirm_password" class="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-teal-500 focus:outline-none transition-colors" placeholder="Confirm your password" required>
        </div>
        <?php if ($error): ?>
          <div class="bg-red-50 text-red-600 px-4 py-3 rounded-xl text-sm"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <button type="submit" class="w-full py-4 rounded-2xl font-bold text-xl bg-gradient-to-r from-teal-500 to-blue-500 text-white shadow-lg hover:shadow-xl transition-all hover:scale-105">
          Create Account
        </button>
      </form>

      <div class="mt-6 text-center">
        <span class="text-gray-600">Already have an account? </span>
        <a href="index.php?page=login" class="text-teal-600 font-semibold hover:text-teal-700 transition-colors">Log in</a>
      </div>
    </div>
  </div>
</div>
