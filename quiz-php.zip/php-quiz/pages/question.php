<?php
$quiz = $_SESSION['quiz'];
$question = $quiz['questions'][$quiz['currentIndex']];
$total = count($quiz['questions']);
$current = $quiz['currentIndex'];
$showFeedback = $quiz['showFeedback'];
$selectedAnswer = $quiz['selectedAnswer'];
$progress = (int)(($current + 1) / $total * 100);
$letters = ['A', 'B', 'C', 'D'];
?>
<div class="min-h-screen bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 flex flex-col p-4">
  <div class="flex-1 flex flex-col max-w-2xl w-full mx-auto py-6">

    <!-- Header -->
    <div class="mb-6">
      <div class="flex items-center justify-between mb-3">
        <div class="flex items-center gap-2 bg-white/20 backdrop-blur-sm rounded-full px-4 py-2">
          <span class="text-2xl"><?= $question['categoryEmoji'] ?></span>
          <span class="text-white font-semibold"><?= htmlspecialchars($question['categoryName']) ?></span>
        </div>
        <div class="bg-white/20 backdrop-blur-sm rounded-full px-4 py-2">
          <span class="text-white font-bold"><?= $current + 1 ?> / <?= $total ?></span>
        </div>
      </div>
      <div class="h-2 bg-white/20 rounded-full overflow-hidden">
        <div class="h-full bg-white transition-all duration-300" style="width: <?= $progress ?>%"></div>
      </div>
    </div>

    <!-- Question -->
    <div class="bg-white rounded-3xl p-6 mb-6 shadow-xl">
      <h2 class="text-2xl font-bold text-gray-800"><?= htmlspecialchars($question['question']) ?></h2>
    </div>

    <!-- Answers -->
    <?php if ($question['type'] === 'multiple'): ?>
      <div class="space-y-3 flex-1">
        <?php foreach ($question['options'] as $i => $option):
          $isSelected = $selectedAnswer === $i;
          $isCorrect = $i === $question['correctAnswer'];
          $btnClass = 'bg-white hover:bg-gray-50';
          $textClass = 'text-gray-800';
          $letterClass = 'bg-purple-100 text-purple-600';
          if ($showFeedback && $isCorrect) { $btnClass = 'bg-green-500'; $textClass = 'text-white'; $letterClass = 'bg-white/20 text-white'; }
          if ($showFeedback && $isSelected && !$isCorrect) { $btnClass = 'bg-red-500'; $textClass = 'text-white'; $letterClass = 'bg-white/20 text-white'; }
        ?>
          <?php if (!$showFeedback): ?>
            <form method="POST" action="index.php">
              <input type="hidden" name="action" value="answer">
              <input type="hidden" name="answer" value="<?= $i ?>">
              <button type="submit" class="w-full p-5 rounded-2xl transition-all duration-200 <?= $btnClass ?> shadow-lg hover:shadow-xl flex items-center gap-4 text-left">
                <div class="w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg flex-shrink-0 <?= $letterClass ?>">
                  <?= $letters[$i] ?>
                </div>
                <span class="font-semibold text-lg <?= $textClass ?>"><?= htmlspecialchars($option) ?></span>
              </button>
            </form>
          <?php else: ?>
            <div class="w-full p-5 rounded-2xl <?= $btnClass ?> shadow-lg flex items-center gap-4 cursor-default">
              <div class="w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg flex-shrink-0 <?= $letterClass ?>">
                <?= $letters[$i] ?>
              </div>
              <span class="font-semibold text-lg <?= $textClass ?>"><?= htmlspecialchars($option) ?></span>
            </div>
          <?php endif; ?>
        <?php endforeach; ?>
      </div>

    <?php else: // boolean ?>
      <div class="grid grid-cols-2 gap-4 flex-1">
        <?php foreach ($question['options'] as $i => $option):
          $isSelected = $selectedAnswer === $i;
          $isCorrect = $i === $question['correctAnswer'];
          $btnClass = 'bg-white hover:bg-gray-50 text-gray-800';
          if ($showFeedback && $isCorrect) $btnClass = 'bg-green-500 text-white';
          if ($showFeedback && $isSelected && !$isCorrect) $btnClass = 'bg-red-500 text-white';
        ?>
          <?php if (!$showFeedback): ?>
            <form method="POST" action="index.php">
              <input type="hidden" name="action" value="answer">
              <input type="hidden" name="answer" value="<?= $i ?>">
              <button type="submit" class="w-full p-8 rounded-3xl transition-all duration-200 <?= $btnClass ?> shadow-lg hover:shadow-xl flex items-center justify-center min-h-[160px]">
                <span class="font-bold text-3xl"><?= htmlspecialchars($option) ?></span>
              </button>
            </form>
          <?php else: ?>
            <div class="w-full p-8 rounded-3xl <?= $btnClass ?> shadow-lg flex items-center justify-center min-h-[160px]">
              <span class="font-bold text-3xl"><?= htmlspecialchars($option) ?></span>
            </div>
          <?php endif; ?>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <!-- Next button -->
    <?php if ($showFeedback): ?>
      <form method="POST" action="index.php" class="mt-6">
        <input type="hidden" name="action" value="next_question">
        <button type="submit" class="w-full py-4 rounded-2xl font-bold text-xl bg-white text-purple-600 shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-200">
          <?= $current < $total - 1 ? 'Next Question' : 'See Results' ?>
        </button>
      </form>
    <?php endif; ?>

  </div>
</div>
