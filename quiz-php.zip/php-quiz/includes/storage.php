<?php

define('DATA_DIR', __DIR__ . '/../data/');
define('USERS_FILE', DATA_DIR . 'users.json');
define('STATS_FILE', DATA_DIR . 'stats.json');

function ensureDataDir(): void {
    if (!is_dir(DATA_DIR)) {
        mkdir(DATA_DIR, 0755, true);
    }
}

function readJson(string $file): array {
    if (!file_exists($file)) return [];
    $content = file_get_contents($file);
    return json_decode($content, true) ?: [];
}

function writeJson(string $file, array $data): void {
    ensureDataDir();
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT), LOCK_EX);
}

function getAllUsers(): array {
    return readJson(USERS_FILE);
}

function saveAllUsers(array $users): void {
    writeJson(USERS_FILE, $users);
}

function createUser(string $username, string $password): array {
    $users = getAllUsers();
    foreach ($users as $u) {
        if (strtolower($u['username']) === strtolower($username) && !$u['isGuest']) {
            throw new Exception('Username already exists');
        }
    }
    $newUser = [
        'id' => 'user_' . time() . '_' . rand(1000, 9999),
        'username' => $username,
        'passwordHash' => password_hash($password, PASSWORD_DEFAULT),
        'isGuest' => false,
        'createdAt' => time(),
    ];
    $users[] = $newUser;
    saveAllUsers($users);

    $stats = ['userId' => $newUser['id'], 'totalGamesPlayed' => 0, 'categoryScores' => []];
    saveUserStats($stats);

    return $newUser;
}

function loginUser(string $username, string $password): array {
    $users = getAllUsers();
    foreach ($users as $u) {
        if (strtolower($u['username']) === strtolower($username) && !$u['isGuest']) {
            if (password_verify($password, $u['passwordHash'])) {
                return $u;
            }
            throw new Exception('Invalid username or password');
        }
    }
    throw new Exception('Invalid username or password');
}

function createGuestUser(): array {
    $guest = [
        'id' => 'guest_' . time() . '_' . rand(1000, 9999),
        'username' => 'Guest' . rand(1000, 9999),
        'isGuest' => true,
        'createdAt' => time(),
    ];
    $stats = ['userId' => $guest['id'], 'totalGamesPlayed' => 0, 'categoryScores' => []];
    saveUserStats($stats);
    return $guest;
}

function getUserStats(string $userId): array {
    $allStats = readJson(STATS_FILE);
    return $allStats[$userId] ?? ['userId' => $userId, 'totalGamesPlayed' => 0, 'categoryScores' => []];
}

function saveUserStats(array $stats): void {
    $allStats = readJson(STATS_FILE);
    $allStats[$stats['userId']] = $stats;
    writeJson(STATS_FILE, $allStats);
}

function updateScore(string $userId, string $categoryId, int $score, int $totalQuestions): void {
    $stats = getUserStats($userId);
    $found = false;
    foreach ($stats['categoryScores'] as &$cs) {
        if ($cs['categoryId'] === $categoryId) {
            if ($score > $cs['bestScore']) {
                $cs['bestScore'] = $score;
                $cs['totalQuestions'] = $totalQuestions;
            }
            $cs['attempts']++;
            $cs['lastPlayed'] = time();
            $found = true;
            break;
        }
    }
    if (!$found) {
        $stats['categoryScores'][] = [
            'categoryId' => $categoryId,
            'bestScore' => $score,
            'totalQuestions' => $totalQuestions,
            'attempts' => 1,
            'lastPlayed' => time(),
        ];
    }
    $stats['totalGamesPlayed']++;
    saveUserStats($stats);
}

function getLeaderboard(string $categoryId, string $currentUserId = ''): array {
    $allStats = readJson(STATS_FILE);
    $users = getAllUsers();
    $usersById = [];
    foreach ($users as $u) { $usersById[$u['id']] = $u; }

    $entries = [];
    foreach ($allStats as $stats) {
        $user = $usersById[$stats['userId']] ?? null;
        if (!$user || $user['isGuest']) continue;

        foreach ($stats['categoryScores'] as $cs) {
            if ($cs['categoryId'] === $categoryId) {
                $entries[] = [
                    'userId' => $stats['userId'],
                    'username' => $user['username'],
                    'score' => $cs['bestScore'],
                    'totalQuestions' => $cs['totalQuestions'],
                    'percentage' => (int) round(($cs['bestScore'] / $cs['totalQuestions']) * 100),
                ];
                break;
            }
        }
    }

    usort($entries, fn($a, $b) => $b['percentage'] <=> $a['percentage'] ?: $b['score'] <=> $a['score']);

    $result = [];
    foreach ($entries as $i => $entry) {
        $result[] = array_merge($entry, [
            'rank' => $i + 1,
            'isCurrentUser' => $entry['userId'] === $currentUserId,
        ]);
    }
    return $result;
}

function getUserRankInCategory(string $userId, string $categoryId): ?int {
    $lb = getLeaderboard($categoryId, $userId);
    foreach ($lb as $entry) {
        if ($entry['userId'] === $userId) return $entry['rank'];
    }
    return null;
}
