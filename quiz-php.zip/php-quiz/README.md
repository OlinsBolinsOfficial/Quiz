# QuizMaster – PHP Edition

A full PHP conversion of the original React/TypeScript quiz app.

## Requirements

- PHP 8.0+
- A web server (Apache, Nginx, or PHP's built-in server)
- Write permissions on the `data/` directory

## Running locally

```bash
# From the php-quiz directory:
php -S localhost:8000
```

Then open http://localhost:8000

## Project Structure

```
php-quiz/
├── index.php               # Entry point, routing, and POST handling
├── includes/
│   ├── quiz_data.php       # All quiz questions and categories
│   └── storage.php         # User/stats persistence (JSON files)
├── pages/
│   ├── welcome.php         # Landing screen
│   ├── login.php           # Login form
│   ├── signup.php          # Registration form
│   ├── category_select.php # Pick quiz categories
│   ├── question.php        # Question display + answer submission
│   ├── results.php         # Score summary
│   ├── profile.php         # User stats
│   └── leaderboard.php     # Category leaderboards
└── data/                   # Auto-created; stores users.json and stats.json
```

## How data is stored

- **Users**: `data/users.json` – array of user objects with hashed passwords
- **Stats**: `data/stats.json` – per-user game stats keyed by user ID
- **Sessions**: PHP native sessions for login state and active quiz state

## Key differences from the Node.js version

| Feature | Original (React) | PHP Version |
|---|---|---|
| Storage | `localStorage` | JSON files on disk |
| Auth | No real passwords | `password_hash` / `password_verify` |
| State | React `useState` | PHP `$_SESSION` |
| Routing | React state machine | `?page=` GET param |
| UI | Tailwind via npm | Tailwind CDN |
