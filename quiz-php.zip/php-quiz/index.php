<?php
session_start();

require_once __DIR__ . '/includes/storage.php';
require_once __DIR__ . '/includes/quiz_data.php';

// Handle AJAX/POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'login') {
        try {
            $user = loginUser(trim($_POST['username'] ?? ''), $_POST['password'] ?? '');
            $_SESSION['user'] = $user;
            $_SESSION['error'] = '';
            header('Location: index.php?page=category-select');
        } catch (Exception $e) {
            $_SESSION['error'] = $e->getMessage();
            header('Location: index.php?page=login');
        }
        exit;
    }

    if ($action === 'signup') {
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';
        $error = '';

        if (strlen($username) < 3) $error = 'Username must be at least 3 characters';
        elseif (strlen($password) < 4) $error = 'Password must be at least 4 characters';
        elseif ($password !== $confirm) $error = 'Passwords do not match';

        if ($error) {
            $_SESSION['error'] = $error;
            header('Location: index.php?page=signup');
            exit;
        }
        try {
            $user = createUser($username, $password);
            $_SESSION['user'] = $user;
            $_SESSION['error'] = '';
            header('Location: index.php?page=category-select');
        } catch (Exception $e) {
            $_SESSION['error'] = $e->getMessage();
            header('Location: index.php?page=signup');
        }
        exit;
    }

    if ($action === 'guest') {
        $guest = createGuestUser();
        $_SESSION['user'] = $guest;
        header('Location: index.php?page=category-select');
        exit;
    }

    if ($action === 'start_quiz') {
        $selected = $_POST['categories'] ?? [];
        if (empty($selected)) {
            header('Location: index.php?page=category-select');
            exit;
        }
        $categories = getCategories();
        $allQuestions = [];
        foreach ($categories as $cat) {
            if (in_array($cat['id'], $selected)) {
                foreach ($cat['questions'] as $q) {
                    $allQuestions[] = array_merge($q, [
                        'categoryName' => $cat['name'],
                        'categoryEmoji' => $cat['emoji'],
                        'categoryId' => $cat['id'],
                    ]);
                }
            }
        }
        shuffle($allQuestions);
        $_SESSION['quiz'] = [
            'questions' => $allQuestions,
            'currentIndex' => 0,
            'score' => 0,
            'selectedCategories' => $selected,
            'selectedAnswer' => null,
            'showFeedback' => false,
        ];
        header('Location: index.php?page=question');
        exit;
    }

    if ($action === 'answer') {
        $answerIndex = (int)($_POST['answer'] ?? -1);
        $quiz = $_SESSION['quiz'] ?? null;
        if ($quiz !== null) {
            $question = $quiz['questions'][$quiz['currentIndex']];
            $quiz['selectedAnswer'] = $answerIndex;
            $quiz['showFeedback'] = true;
            if ($answerIndex === $question['correctAnswer']) {
                $quiz['score']++;
            }
            $_SESSION['quiz'] = $quiz;
        }
        header('Location: index.php?page=question');
        exit;
    }

    if ($action === 'next_question') {
        $quiz = $_SESSION['quiz'] ?? null;
        if ($quiz !== null) {
            if ($quiz['currentIndex'] < count($quiz['questions']) - 1) {
                $quiz['currentIndex']++;
                $quiz['selectedAnswer'] = null;
                $quiz['showFeedback'] = false;
                $_SESSION['quiz'] = $quiz;
                header('Location: index.php?page=question');
            } else {
                // Save score if single category and logged in
                $user = $_SESSION['user'] ?? null;
                if ($user && !$user['isGuest'] && count($quiz['selectedCategories']) === 1) {
                    updateScore($user['id'], $quiz['selectedCategories'][0], $quiz['score'], count($quiz['questions']));
                    $_SESSION['user'] = $user; // refresh
                }
                $_SESSION['last_quiz'] = $quiz;
                unset($_SESSION['quiz']);
                header('Location: index.php?page=results');
            }
        } else {
            header('Location: index.php?page=category-select');
        }
        exit;
    }

    if ($action === 'logout') {
        session_destroy();
        header('Location: index.php');
        exit;
    }

    if ($action === 'play_again') {
        $lastQuiz = $_SESSION['last_quiz'] ?? null;
        if ($lastQuiz) {
            $selected = $lastQuiz['selectedCategories'];
            $categories = getCategories();
            $allQuestions = [];
            foreach ($categories as $cat) {
                if (in_array($cat['id'], $selected)) {
                    foreach ($cat['questions'] as $q) {
                        $allQuestions[] = array_merge($q, [
                            'categoryName' => $cat['name'],
                            'categoryEmoji' => $cat['emoji'],
                            'categoryId' => $cat['id'],
                        ]);
                    }
                }
            }
            shuffle($allQuestions);
            $_SESSION['quiz'] = [
                'questions' => $allQuestions,
                'currentIndex' => 0,
                'score' => 0,
                'selectedCategories' => $selected,
                'selectedAnswer' => null,
                'showFeedback' => false,
            ];
            header('Location: index.php?page=question');
        } else {
            header('Location: index.php?page=category-select');
        }
        exit;
    }
}

// Determine page
$user = $_SESSION['user'] ?? null;
$page = $_GET['page'] ?? ($user ? 'category-select' : 'welcome');

// Redirect if not logged in
if (!$user && !in_array($page, ['welcome', 'login', 'signup'])) {
    header('Location: index.php?page=welcome');
    exit;
}

// Layout header
function renderHeader(string $title = 'QuizMaster'): void {
    echo '<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>' . htmlspecialchars($title) . '</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
  body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
  .transition-all { transition: all 0.2s ease; }
  .backdrop-blur-sm { backdrop-filter: blur(4px); }
  .scale-105:hover { transform: scale(1.05); }
</style>
</head>
<body>';
}

function renderFooter(): void {
    echo '</body></html>';
}

// Pages
switch ($page) {
    case 'welcome':
        renderHeader();
        include __DIR__ . '/pages/welcome.php';
        renderFooter();
        break;

    case 'login':
        renderHeader('Login – QuizMaster');
        include __DIR__ . '/pages/login.php';
        renderFooter();
        break;

    case 'signup':
        renderHeader('Sign Up – QuizMaster');
        include __DIR__ . '/pages/signup.php';
        renderFooter();
        break;

    case 'category-select':
        renderHeader('Choose Categories – QuizMaster');
        include __DIR__ . '/pages/category_select.php';
        renderFooter();
        break;

    case 'question':
        $quiz = $_SESSION['quiz'] ?? null;
        if (!$quiz) { header('Location: index.php?page=category-select'); exit; }
        renderHeader('Question – QuizMaster');
        include __DIR__ . '/pages/question.php';
        renderFooter();
        break;

    case 'results':
        $lastQuiz = $_SESSION['last_quiz'] ?? null;
        if (!$lastQuiz) { header('Location: index.php?page=category-select'); exit; }
        renderHeader('Results – QuizMaster');
        include __DIR__ . '/pages/results.php';
        renderFooter();
        break;

    case 'profile':
        renderHeader('Profile – QuizMaster');
        include __DIR__ . '/pages/profile.php';
        renderFooter();
        break;

    case 'leaderboard':
        renderHeader('Leaderboard – QuizMaster');
        include __DIR__ . '/pages/leaderboard.php';
        renderFooter();
        break;

    default:
        header('Location: index.php');
        exit;
}
